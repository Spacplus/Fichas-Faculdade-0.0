<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro e Login</title>
</head>
<header>
        <h1>Bem-vindo ao Mundo do RPG!</h1>
        <nav>
            <ul>
                <li><a href="/index.php">Início</a></li>
                <li><a href="classes.html">Classes de RPG</a></li>.
                <li><a href="ficha.html">Crie sua ficha</a></li>
                <li><a href="sobre.html">Nossa Equipe</a></li>
                <li><a href="cadastroUser">login / Cadastro</a></li>
            </ul>
        </nav>
    </header>