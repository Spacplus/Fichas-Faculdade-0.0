<?php
require($_SERVER['DOCUMENT_ROOT'] . '/_config.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
} 


// Função para gerar um token CSRF
function generateCSRFToken() {
    return bin2hex(random_bytes(32));
}

// Gera um token CSRF e armazena na sessão
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = generateCSRFToken();
}

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica o token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('Token CSRF inválido.');
    }

    // Recebe os dados do formulário e valida
    $nome = filter_var(trim($_POST['nome']), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    // Validações adicionais
    if (strlen($senha) < 8) {
        die('A senha deve ter pelo menos 8 caracteres.');
    }

    // Prepara a declaração SQL
    $sql = "INSERT INTO users (nome, email, senha) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $email, $senha);

    try {
        if ($stmt->execute()) {
            // Cadastro realizado com sucesso
            header('Location: /');
            exit;
        } else {
            // Trata erros específicos
            if ($conn->errno === 1062) {
                die('Email já cadastrado.');
            } else {
                // Registra erro em log
                error_log("Erro ao cadastrar usuário: " . $conn->error, 3, 'error.log');
                die('Ocorreu um erro ao realizar o cadastro.');
            }
        }
    } catch (Exception $e) {
        // Trata exceções
        echo 'Ocorreu um erro inesperado: ' . $e->getMessage();
    } finally {
        // Fecha a conexão com o banco de dados
        $stmt->close();
        $conn->close();
    }
}
require($_SERVER['DOCUMENT_ROOT'] . '/header.php');
?>
<link rel="stylesheet" href="style.css">
<form action="" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>
        <br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <br>
        <label for="senha">Senha:</label>   

        <input type="password" id="senha" name="senha" required>
        <br>
        <input type="submit" value="Cadastrar">
    </form>
